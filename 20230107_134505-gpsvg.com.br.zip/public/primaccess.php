<?php
	require 'config/config.php';
	require 'app/core/Core.php';
	require 'vendor/autoload.php';

    if(isset($_POST['credencial']) && !empty($_POST['credencial'])){
        $credencial = addslashes($_POST['credencial']);
        $chave = addslashes($_POST['chave']);
        $chave2 = addslashes($_POST['chave']);

    if($chave == $chave2){
        $chave = md5(addslashes($_POST['chave']));
        $db = new PDO("mysql:dbname=".BANCO.";host=".SERVIDOR,USUARIO,SENHA, array(\PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
        $sql = "SELECT * FROM usuario WHERE email = '$credencial' AND senha = 'PADRÃO'";
        $sql = $db->query($sql);

        if($sql->rowCount() > 0){
                $sql = "UPDATE usuario SET senha =:chave WHERE email =:credencial";
                $sql = $db->prepare($sql);
                $sql->bindValue(":credencial", $credencial);
                $sql->bindValue(":chave", $chave);
                $sql->execute();
                header("Location: index.php");
            }else{
                session_start();
                $msg = "usuário: $credencial, já tem acesso.";
                $_SESSION['msg'] = $msg;
                header("Location: index.php");
            }
    }
} 
      

?>
<!DOCTYPE html>
<html lang="pt-Br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/estilo.css" />
    <title>Primeiro Acesso - sistema GPS</title>
</head>
<body>
    <div class="primeiroAcesso">
        <form method="post">
            <p></p>
            <br><br><br>
            <label>Informe seu usuário - email</label>
            <input type="email" name="credencial" autofocus>
            <br><br>
            
            <label>Nome completo</label>
            <input type="text" name="nome" required>
            <br><br>
            
            <label>CPF</label>
            <input type="text" name="cpf" required maxlenght="11">
            <br><br>
                
            <label>Crie uma senha </label>
            <input type="password" minlength="6" name="chave">
                <br><br>
            <label>repetir a senha recem criada </label>
            <input type="password" minlength="6" name="chave2">
            <input type="submit" value="Criar acesso">
        </form>
    </div>    
</body>


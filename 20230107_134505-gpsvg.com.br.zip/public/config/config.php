<?php

define("SERVIDOR", "mysql831.umbler.com");
define("BANCO", "gps");
define("USUARIO", "vg-gps-pad");
define("SENHA", "#2958#ilimitY#newJ0b");
define("CHARSET", 'array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"');

define('CONTROLLER_PADRAO', 'Home');
define('METODO_PADRAO', 'index');
define('NAMESPACE_CONTROLLER', '\app\\controllers\\');
define('UPLOAD_PRINCIPAL', '/home/defaultwebsite/public/uploads/arquivos/');
define('LIMITE_LISTA', 10);
define('URL_BASE', 'https://gpsvg.com.br/');

<?php
namespace app\classes;

class Classe {
 
        $id_fase;
        $fase;

        
}

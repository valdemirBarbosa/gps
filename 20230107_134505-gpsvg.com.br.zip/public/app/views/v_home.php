<div class="base-home">
	<h1 class="titulo-pagina">SEJA BEM VINDOS</h1>
	<meta charset="utf-8">	

</div>

 <div class="img">
	<img class="imagem" src="<?php echo URL_BASE . 'assets/img/logo2022Agosto.jpg' ?>" alt="Logomarca da Prefeitura Municipal de Várzea Grande" width="400" height="200">	
</div>


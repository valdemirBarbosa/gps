<div class="rodape">
		<p>Direitos reservados a valbs.com.br</p>
	</div>

<div class="radio">
			<input checked type="radio" name="operador" value="1" checked>
			<label>Exatamente igual</label>	

			<input type="radio" name="operador" value="2">
			<label>Começa com</label>	

			<input type="radio" name="operador" value="3">
			<label>Contem</label>	

			<input type="radio" name="operador" value="4">
			<label>Termina com</label>	
</div>
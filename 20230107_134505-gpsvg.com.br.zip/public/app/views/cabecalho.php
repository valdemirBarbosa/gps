<div>
<h3 class="span">GPS - <span>G</span>erenciador de <span>P</span>rocesso de <span>S</span>indicância</h3>
</div>

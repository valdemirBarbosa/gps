<html>
<head>
<meta charset="utf-8">
<title>gPs</title>
<meta name="viewport" content="width=device-width, initial-scale=1,shrink-to-fit=no" />
<link rel="stylesheet" href="<?php echo URL_BASE ."/assets/css/meu.css" ?>" />
</head>
<body>
<header>
    <div class="logo">
        <ul class="menu">
            <li> <a href="a">Sobre</a> </li>
            <li> <a href="a">Contatos</a> </li>
            <li> <a href="a">Produtos</a> </li>
            <li> <a href="a">Serviços</a> </li>

        </ul>
    </div>
</header>

</body>
</html>

-- --------------------------------------------------------

--
-- Estrutura da tabela `denunciado`
--

CREATE TABLE `denunciado` (
  `id_denunciado` int(11) NOT NULL,
  `id_denuncia` int(11) NOT NULL,
  `id_servidor` int(11) NOT NULL,
  `nome_provisorio` varchar(80) NOT NULL,
  `observacao` text NOT NULL,
  `anexo` int(11) NOT NULL,
  `data_digitacao` datetime NOT NULL DEFAULT current_timestamp(),
  `user` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `denunciado`
--

INSERT INTO `denunciado` (`id_denunciado`, `id_denuncia`, `id_servidor`, `nome_provisorio`, `observacao`, `anexo`, `data_digitacao`, `user`) VALUES(1, 1, 1, '', 'incluido manualmente no banco de dados', 1, '2021-06-02 00:00:00', 1);

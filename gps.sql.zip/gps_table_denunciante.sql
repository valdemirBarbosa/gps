
-- --------------------------------------------------------

--
-- Estrutura da tabela `denunciante`
--

CREATE TABLE `denunciante` (
  `id_denunciante` int(11) NOT NULL,
  `nome_denunciante` varchar(80) NOT NULL,
  `observacao` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `denunciante`
--

INSERT INTO `denunciante` (`id_denunciante`, `nome_denunciante`, `observacao`) VALUES(1, 'ADM', 'SEM OBS');
INSERT INTO `denunciante` (`id_denunciante`, `nome_denunciante`, `observacao`) VALUES(3, 'TCE/MT - TRIBUNAL DE CONTAS DO ESTADO DE MATO GROSSO', 'SEM OBSERVAÇÃO');
INSERT INTO `denunciante` (`id_denunciante`, `nome_denunciante`, `observacao`) VALUES(19, 'CONTROLADORIA MUNICIPAL', 'CONTROLE INTERNO					');


-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `email`, `senha`, `data_criacao`) VALUES(1, 'val@gmail.com', '123', '2021-02-26 21:55:12');
INSERT INTO `usuario` (`id_usuario`, `email`, `senha`, `data_criacao`) VALUES(2, 'leyd@gmail.com', '#15', '2021-03-14 02:55:17');


-- --------------------------------------------------------

--
-- Estrutura da tabela `processado`
--

CREATE TABLE `processado` (
  `id_processo` int(11) NOT NULL,
  `id_servidor` int(11) NOT NULL,
  `id_denuncia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

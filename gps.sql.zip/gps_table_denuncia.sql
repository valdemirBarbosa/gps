
-- --------------------------------------------------------

--
-- Estrutura da tabela `denuncia`
--

CREATE TABLE `denuncia` (
  `id_denuncia` int(11) NOT NULL,
  `denuncia_fato` varchar(100) NOT NULL,
  `id_denunciante` int(4) NOT NULL,
  `tipo_documento` varchar(20) NOT NULL,
  `numero_documento` varchar(20) NOT NULL,
  `data_entrada` date NOT NULL,
  `observacao` text NOT NULL,
  `data_digitacao` datetime NOT NULL DEFAULT current_timestamp(),
  `user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `denuncia`
--

INSERT INTO `denuncia` (`id_denuncia`, `denuncia_fato`, `id_denunciante`, `tipo_documento`, `numero_documento`, `data_entrada`, `observacao`, `data_digitacao`, `user`) VALUES(1, 'ROUBO DE AR CONDICIONADO', 3, 'CI', '20015', '2021-06-22', 'NINGUÉM VIU O ROSTO PORQUE ERA NOITE ESCURA', '2021-06-01 20:43:13', NULL);
INSERT INTO `denuncia` (`id_denuncia`, `denuncia_fato`, `id_denunciante`, `tipo_documento`, `numero_documento`, `data_entrada`, `observacao`, `data_digitacao`, `user`) VALUES(2, 'ROUBO DE AR CONDICIONADO', 3, 'CI', '20015', '2021-06-22', 'NINGUÉM VIU O ROSTO PORQUE ERA NOITE ESCURA', '2021-06-01 20:43:18', NULL);
